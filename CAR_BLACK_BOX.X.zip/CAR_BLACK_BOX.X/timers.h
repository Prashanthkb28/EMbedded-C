
#ifndef TIMERS_H
#define	TIMERS_H

//FUNCTION TO  INITIALIZE TIMER 2
void init_timer2(void);

#endif	/* TIMERS_H */