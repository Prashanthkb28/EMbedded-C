/*
 * File:   main.c
 * Author: PRASHANTH K B
 * Description : Implement system sleep and wake up while Interrupt on change
 *                INT0 as Interrupt to wake. 
 *
 * Created on February 13, 2024, 7:45 PM
 */


#include <xc.h>
#include "main.h"
#include "timers.h"
#include "ssd.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)

extern int count1;
static void init_config(void) {
    
    LED_ARRAY1_DDR7 = 0;
    init_ssd();
    init_timer0();
    LED1 = 0;    

    /* Enable all the Global Interrupts */
    GIE = 1;
    
    INTE = 1;
 
}

void main(void) {
    
    static unsigned char ssd[]={ONE, TWO, THREE, FOUR};
    init_config();

    while (1) {
               
        if(count1 <= 5)           
        {
            
            display(ssd);             
        }                                 
        // after 5 seconds  
        if( count1 > 5)           
        {            
            TMR0IE = 0;          
            count1=0;
            LED_ARRAY1 = 0x00;
            LED_ARRAY2 = 0x00;
            SLEEP();
            
        } 
        
        
        
        
    }
    
}
