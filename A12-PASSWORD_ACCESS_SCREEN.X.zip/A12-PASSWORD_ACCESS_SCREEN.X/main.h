#ifndef MAIN_H
#define	MAIN_H
#include "matrix_keypad.h"
#include "timers.h"
#include <xc.h>
#include "clcd.h"

#define LED7                RD7
#define LED_ARRAY1          PORTD
#define LED_ARRAY1_DDR      TRISD7

#endif	/* MAIN_H */
