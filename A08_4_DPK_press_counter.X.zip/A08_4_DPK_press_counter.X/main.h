/* 
 * File:   main.h
 * Author: home
 *
 * Created on January 31, 2024, 12:38 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* MAIN_H */

