/*
 * File:   main.c
 * Author: PRASHANTH K B
 * Description : Implement a 4 digit key press counter
 *
 * Created on January 31, 2024, 12:38 PM
 */


#include <xc.h>
#include "digital_keypad.h"
#include"ssd.h"

#pragma config WDTE=OFF

void init_config(void)
{
	init_ssd();
	init_digital_keypad();
}

void main(void) {
    init_config();
    static unsigned char ssd[MAX_SSD_CNT]={ZERO,ZERO,ZERO,ZERO};
    static unsigned char digit[] = {ZERO, ONE,TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
	static unsigned  int count = 0;
	unsigned char key;
    static unsigned char time =0,flag=0;
	while(1)
	{
        /*reading key pressed*/
        key = read_digital_keypad(LEVEL);
        if(key == SW1)
        {
            // long press
            if(time++ > 200)
            {
                count=0;
                time=0;
                flag=1;
            }
           else if(time > 200)
            {
                time=201;
            }
          
        }
        else if( time > 0 && time < 200)  // short press
        {
            if(flag == 1)
            {
                 count=0;
                 flag=0;
            }
            else
                count++;
            time=0;
           
           if (count > 9999) 
            {
                count = 0;
            }
        }
       
      
        
            ssd[3] = digit[count % 10];
            ssd[2] = digit[(count % 100)/10];
            ssd[1] = digit[(count % 1000)/100];
            ssd[0] = digit[count / 1000];
       
            /*display on ssd*/
            display(ssd);
   
        
    }
}
