/*
 * File:   main.c
 * Author: PRASHANTH K B
 * Description : Implement a point brightness control
 * Created on February 14, 2024, 5:15 PM
 */


#include <xc.h>
#include "main.h"
#include "timers.h"
#include "digital_keypad.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)

#define PERIOD    100

int  duty_cycle = 50;
int flag=0;
static unsigned long int loop_counter = 0, wait = 0;

void init_config(void) {
    	
    LED_ARRAY = 0x00;    // off all LED
	LED_ARRAY_DDR = 0x00;
    
    init_digital_keypad();
    init_timer0();
    
    /*Global interrupt enable*/
    GIE = 1;    
}
void main(void) {
    init_config();
    unsigned char key;
    
    while (1) {
        
        /* read the digital  key press switch 1 (RB0)*/
        key = read_digital_keypad(STATE);       
      
            if (key == SW1)
            {
                /*changing duty cycle to 100 on key press*/
                  duty_cycle=100;
                  flag=1;
            }
         
        /*50%-LED Blinking*/
        if (loop_counter < duty_cycle)
        {
            LED1 = 1;
        }
        else if (loop_counter > duty_cycle)
        {
            LED1 = 0;
        }
        if(loop_counter++ == PERIOD)
        {
            loop_counter = 0;
        }
    }
    
}