#include <xc.h>
extern int duty_cycle,flag;
void __interrupt() isr(void)
{
    static unsigned long int count1 = 0, count2 = 0;
    
    if (TMR0IF == 1)
    {
        TMR0 = TMR0 + 8;
        if (++count1 == 20000)
        {
            count1 = 0;
            // after 5 sec making duty cycle to 10
            if(++count2 == 5)
            {
                count2 = 0;
                if( flag)
                {
                  duty_cycle=10;
                  flag=0;
                }
              
            }
               
        }
        TMR0IF = 0;
    }
}