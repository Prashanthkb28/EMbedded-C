#include <xc.h>
#include "main.h"

void __interrupt() isr(void)
{
    static unsigned int count1 = 0 ;  
    static unsigned int count2 = 0;
    static unsigned int count3 = 0 ;
    /* timer0 for  1 sec */
    if (TMR0IF == 1)
    {
        /* TMR0 Register value + 6 (offset count to get 250 ticks) + 2 Instant Cycle */
        TMR0 = TMR0 + 8;
        
        if (++count1 == 20000)
        {
            count1 = 0;        
            LED1 = !LED1;
        }      
        TMR0IF = 0;
    }  
    /* timer1 for  1 sec */
    if(TMR1IF == 1)       
    {                   
        
        TMR1 = TMR1 + 3038;
        if (++count2 == 80)              
        {                        
            count2 = 0;                    
            LED2 = !LED2;    
        }                      
         TMR1IF=0;               
    }  
    /* timer2 for  1 sec */
    if (TMR2IF == 1)
    {
        
        if (++count3 == 20000 )
        {
            count3 = 0;
            
            LED3 = !LED3;
        }       
        TMR2IF = 0;       
    }
}
