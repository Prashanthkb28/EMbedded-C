/*
 * File:   main.c
 * Author: PRASHANTH K B
 * Description : Implement a scrolling number marquee with direction control
 *
 * Created on February 20, 2024, 6:38 PM
 */


#include <xc.h>
#include "ssd.h"
#include "digital_keypad.h"
#pragma config WDTE = OFF        /* Watchdog Timer Enable bit (WDT disabled)*/

static void init_config(void) {
    /*initialization of keypad and ssd*/
    init_ssd();
    init_digital_keypad();
}

void main(void) 
{
    /*initialization of keypad and ssd values*/
    init_config();
    unsigned char ssd[MAX_SSD_CNT];
    unsigned char cur_key = SW1, key;
    unsigned int digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, UNDERSCORE, UNDERSCORE};
    unsigned int wait = 0, count = 0;
    while (1)
    {
        key = read_digital_keypad(STATE);
        
        if ( (key == SW1 || key == SW2 || key == SW3)  && cur_key != key )
		{
			cur_key = key ;		
		}
        if( wait++ == 200)
        {
            wait = 0;
            /*changing the direction on key pressed*/  
            /*Right to left scrolling*/
            if(cur_key == SW1)
            {           
                if(count++ >= 11)
                {
                    count = 0;
                }
            }
            /*Left to right scrolling*/
            else if(cur_key == SW2)
            {         
                if(count-- <= 0)
                {
                    count = 11;
                }
            
            }
        
        }
        /*set the values to ssd*/ 
        ssd[0] = digit[count];
        ssd[1] = digit[(count + 1)%12];
        ssd[2] = digit[(count + 2)%12];
        ssd[3] = digit[(count + 3)%12];

        display(ssd); 
        
    }
}

