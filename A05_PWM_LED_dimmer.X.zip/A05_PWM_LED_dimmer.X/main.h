/* 
 * File:   main.h
 * Author: home
 *
 * Created on February 14, 2024, 7:23 PM
 */

#ifndef MAIN_H
#define	MAIN_H


#define LED_ARRAY       PORTD
#define LED_ARRAY_DDR   TRISD
#define LED1	RD0
#define ON      1
#define OFF     0

#endif	/* MAIN_H */

