/* 
 * File:   timers.h
 * Author: home
 *
 * Created on February 14, 2024, 7:23 PM
 */

#ifndef TIMERS_H
#define	TIMERS_H

void init_timer0(void);

#endif	/* TIMERS_H */

