/*
 * File:   main.c
 * Author: PRASHANTH K B
 * Description :- Implement a static clock on SSD using internal timer
 *
 * Created on February 12, 2024, 2:23 PM
 */


#include <xc.h>
#include "ssd.h"
# include "timers.h"
#pragma config WDTE = OFF /*watch dog timer is enable */

/*variable declaration*/
int hour = 12, min = 0, flag = 0;
/*configuring display and ssd*/
void init_config(void)
{
	init_ssd();
    init_timer0();
    
    /* Enable all the Global Interrupts */
    GIE = 1;
}

void main(void)
{
    static unsigned char ssd[MAX_SSD_CNT];                                                     
    static unsigned char digit[] = {ZERO, ONE,TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};       
	init_config();   
	unsigned int count = 0;
	unsigned int wait = 0;
	unsigned char key ;
    
	while(1)
	{   
        if(flag)                        
        {
            ssd[0] = digit[hour/10];        
            ssd[1] = (digit[hour%10]| DOT);  
            ssd[2] = digit[min/10];     
            ssd[3] = digit[min%10];       
        }
        else                           
        {
            ssd[0] = digit[hour/10];
            ssd[1] = digit[hour%10];
            ssd[2] = digit[min/10];
            ssd[3] = digit[min%10];
        }
        display(ssd);
	}
}