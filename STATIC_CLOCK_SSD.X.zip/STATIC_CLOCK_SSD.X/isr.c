#include <xc.h>

extern int min ,hour, flag; 

void __interrupt() isr(void)
{
    static unsigned int count = 0, multiply = 0;
  
    if (TMR0IF == 1)
    {
        /* TMR0 Register value + 6 (offset count to get 250 ticks) + 2 Instant Cycle */
        TMR0 = TMR0 + 8;
        
        count++;
        /* for every 1/2 second flag get toggled */ 
        if(count == 10000)        
        {              
            flag = !flag;              
        }                            
        else if (count == 20000)          
        {                       
            count = 0;                                      
            multiply++;             
            // increment after every 1 sec                       
            if(multiply == 24)           
            {                                                                       
                multiply = 0;                                
                min++; 
                          
                /* minute value incremented for every 1 minute*/                                                                    
                if(min == 60)                   
                {                     
                    min = 0;                              
                    hour++;          /* hour value get incremented */
                    
                }                  
                if(hour > 23)                  
                {              
                    hour = 0;       /* if greater then 23 hour value decremented to 0*/                 
                }                      
             
            }
                                       
        }
        
    }                
    TMR0IF = 0;   
}
